﻿#内网ip地址
# clientip='10.110.142.94'
clientip='10.110.142.251'

#认证服务器地址
nasip='183.56.17.19'

#mac地址，字母大写，使用-分割
# mac = 'F8-FF-C2-05-53-F9'
mac = 'E4-B2-FB-13-80-49'

#安全码，无需修改
secret='Eshore!@#'

#用户名
username='18102848302'

#密码
password='A11028871'